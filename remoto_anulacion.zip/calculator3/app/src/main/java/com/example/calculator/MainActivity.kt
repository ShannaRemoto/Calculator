package com.example.calculator

import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

private var firstValue: Double = 0.0
class MainActivity : AppCompatActivity() {

    private lateinit var tvDisplay: TextView
    private var currentOperator: String? = null
    private var isOperatorPressed: Boolean = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        tvDisplay = findViewById(R.id.workingsTV)
    }


    fun onNumberClick(view: View) {
        if (isOperatorPressed) {
            tvDisplay.text = ""  // Clear the display for the second operand
            isOperatorPressed = false
        }

        val button = view as Button
        val currentText = tvDisplay.text.toString()

        // If current display is "0", replace it with the clicked number, else append
        if (currentText == "0") {
            tvDisplay.text = button.text
        } else {
            tvDisplay.append(button.text)
        }
    }

    fun onOperatorClick(view: View) {
        val operator = (view as TextView).text.toString()

        try {
            firstValue = tvDisplay.text.toString().toDouble()
        } catch (e: NumberFormatException) {
            firstValue = 0.0
        }

        currentOperator = operator
        isOperatorPressed = true
    }

    fun onMultiplyClick(view: View) {
        val currentText = tvDisplay.text.toString()
        if (currentText.isNotEmpty()) {
            firstValue = currentText.toDoubleOrNull() ?: 0.0
            currentOperator = "*"  // Set operator for multiplication
            isOperatorPressed = true
        }
    }

    fun onSubtractClick(view: View) {
        val currentText = tvDisplay.text.toString()
        if (currentText.isNotEmpty()) {
            firstValue = currentText.toDoubleOrNull() ?: 0.0
            currentOperator = "-"  // Set operator for subtraction
            isOperatorPressed = true
        }
    }

    fun onEqualClick(view: View) {
        val currentText = tvDisplay.text.toString()
        if (currentText.isNotEmpty() && currentOperator != null) {
            val secondValue = currentText.toDoubleOrNull() ?: 0.0  // Capture the second value

            var result = 0.0

            when (currentOperator) {
                "*" -> result = firstValue * secondValue  // Perform multiplication
                "-" -> result = firstValue - secondValue  // Perform subtraction
                "+" -> result = firstValue + secondValue  // Perform addition
                "/" -> result = firstValue / secondValue  // Perform division
            }

            tvDisplay.text = result.toString()  // Display the result

            // Reset flags and operator for the next calculation
            isOperatorPressed = false
            currentOperator = null
        }
    }

    fun allClearAction(view: View) {
        tvDisplay.text = "0"  // Reset the display
        firstValue = 0.0  // Reset the first value
        isOperatorPressed = false  // Reset operator pressed flag
        currentOperator = null  // Reset the operator
    }

    fun onPlusMinusClick(view: View) {
        try {
            val value = tvDisplay.text.toString().toDouble() * -1
            tvDisplay.text = value.toString()
        } catch (e: NumberFormatException) {
            // Handle error if the conversion fails
        }
    }

    fun onPercentClick(view: View) {
        try {
            val value = tvDisplay.text.toString().toDouble()
            tvDisplay.text = (value / 100).toString()
        } catch (e: NumberFormatException) {
            // Handle error if the conversion fails
        }
    }

    fun onDecimalClick(view: View) {
        val text = tvDisplay.text.toString()
        if (!text.contains(".")) {
            tvDisplay.append(".")
        }
    }
}



